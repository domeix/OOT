package dm.methoden;

public abstract class PrintMethoden {
    public static void pupupunkt() {
        System.out.print("  ");
        for (int i = 0; i < 3; i++) {
            System.out.print("  .");
//            try {
//                Thread.sleep(600);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
        }
        System.out.println();
    }
    
    public static void newLine() {
        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("\n");
    }
}
