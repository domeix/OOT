package Handel;

import Pflanzen.Pflanze;

public interface VerkaufInterface {
    public boolean verkaufen(Pflanze p);
}
