package Pflanzen;

public class PflanzenTest {

    public static void main(String[] args) {
        Sonnentau hans = new Sonnentau();
        hans.wachsen();
        System.out.println(hans);
    }

}
