/**
 * Pflanzen aller Art laut Uebungsblatt 1
 * @author Dominique/_k
 *
 */
package Pflanzen;