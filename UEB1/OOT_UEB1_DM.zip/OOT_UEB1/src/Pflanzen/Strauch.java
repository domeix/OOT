package Pflanzen;

public abstract class Strauch extends Pflanze {
    public String blaetter;
    public String frucht;

}
