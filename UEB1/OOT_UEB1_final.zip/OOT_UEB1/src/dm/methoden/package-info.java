/**
 * 
 */
/**
 * @author Dominik
 *
 */
package dm.methoden;